#!/bin/bash
# Created by http://www.vps-murah.net
# Dilarang Keras Mengambil/mencuplik/mengcopy sebagian atau seluruh script ini.
# Hak Cipta VPS-Murah.net (Dilindungi Undang-Undang nomor 19 Tahun 2002)
curl info.vps-murah.net/index.html
echo ""